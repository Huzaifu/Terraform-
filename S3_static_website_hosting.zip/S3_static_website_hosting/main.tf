resource "aws_s3_bucket" "website" {
  bucket = "nextwork-website-project-huzaifa"
}

resource "aws_s3_bucket_ownership_controls" "ownership" {
  bucket = aws_s3_bucket.website.id

  rule {
    object_ownership = "BucketOwnerPreferred"
  }
}

resource "aws_s3_bucket_public_access_block" "public_access" {
  bucket = aws_s3_bucket.website.id

  block_public_acls       = false
  ignore_public_acls      = false
  block_public_policy     = false
  restrict_public_buckets = false
}

resource "aws_s3_bucket_versioning" "versioning" {
  bucket = aws_s3_bucket.website.id

  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_object" "index_file" {
  bucket = aws_s3_bucket.website.id

  source = "${path.module}/index.html"

  key = "index.html"

  content_type = "text/html"

}

resource "aws_s3_object" "website_files" {

  for_each = fileset("${path.module}/NextWork - Everyone should be in a job they love_files", "**")

  bucket = aws_s3_bucket.website.id
  key    = "NextWork - Everyone should be in a job they love_files/${each.value}"
  source = "${path.module}/NextWork - Everyone should be in a job they love_files/${each.value}"

  etag = filemd5("${path.module}/NextWork - Everyone should be in a job they love_files/${each.value}")
}


resource "aws_s3_bucket_website_configuration" "website_configuration" {
  bucket = aws_s3_bucket.website.id

  index_document {
    suffix = "index.html"
  }

}


resource "aws_s3_bucket_acl" "acl" {
  depends_on = [
    aws_s3_bucket_ownership_controls.ownership,
    aws_s3_bucket_public_access_block.public_access
  ]

  bucket = aws_s3_bucket.website.id
  acl    = "public-read"
}

resource "aws_s3_bucket_policy" "public_read" {
  bucket = aws_s3_bucket.website.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid       = "PublicRead"
        Effect    = "Allow"
        Principal = "*"
        Action    = "s3:GetObject"
        Resource  = "${aws_s3_bucket.website.arn}/*"
      }
    ]
  })
}



