# Terraform AWS S3 Static Website Hosting

Deploy a static website on Amazon S3 using Terraform.

## Features

- Creates an Amazon S3 bucket
- Enables bucket versioning
- Configures static website hosting
- Uploads website files automatically
- Configures public read access
- Outputs the website endpoint

## Architecture

```
User
   │
   ▼
Amazon S3
Static Website Hosting
```

## Prerequisites

- Terraform >= 1.6
- AWS CLI configured
- AWS account

## Project Structure

```
.
├── main.tf
├── provider.tf
├── variables.tf
├── outputs.tf
├── versions.tf
└── website/
```

## Usage

Initialize Terraform:

```bash
terraform init
```

Review the execution plan:

```bash
terraform plan
```

Deploy:

```bash
terraform apply
```

Destroy:

```bash
terraform destroy
```

## Example

```hcl
bucket_name = "nextwork-website-project-huzaifa"
```

After deployment Terraform outputs:

```
website_endpoint = nextwork-website-project-huzaifa.s3-website-us-east-1.amazonaws.com
```

## Technologies Used

- Terraform
- AWS S3
- Static Website Hosting
- Infrastructure as Code (IaC)

## Author

Huzaifa Sarfraz