provider "random" {

}
variable "number_of_pets" {
  type        = number
  description = "how many pets you want ?"
}

resource "random_pet" "name" {
  length = var.number_of_pets
}

output "random_pet_name" {
  value = random_pet.name.id
}
