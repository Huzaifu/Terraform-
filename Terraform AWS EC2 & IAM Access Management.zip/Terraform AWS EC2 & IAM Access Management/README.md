# 🚀 AWS EC2 & IAM Access Management with Terraform

This project demonstrates how to provision AWS infrastructure using **Terraform** by creating multiple EC2 instances and implementing **IAM-based access control** using a custom policy. It follows Infrastructure as Code (IaC) best practices by organizing the configuration into modular Terraform files and separating variables from resource definitions.

The project is designed as a hands-on example of how organizations can restrict access to cloud resources based on resource tags while allowing users to perform only the actions they require.

---

# 📖 Project Overview

This Terraform configuration creates:

- Two Amazon EC2 instances
  - Development Environment
  - Production Environment
- A custom IAM Policy
- An IAM Group
- An IAM User
- IAM Group Policy Attachment
- IAM User Group Membership

The IAM policy demonstrates **tag-based authorization**, allowing users to fully manage only development resources while preventing access to production resources.

---

# 🏗️ Architecture

```
                AWS Account
                     │
     ┌───────────────┴───────────────┐
     │                               │
Development EC2                 Production EC2
ENV=development                 ENV=production
     │                               │
     └───────────────┬───────────────┘
                     │
          IAM Policy (Tag Based)
                     │
              IAM Group
                     │
               IAM User
```

---

# ✨ Features

- Infrastructure as Code (Terraform)
- Launch multiple EC2 instances
- Environment-based resource tagging
- IAM Policy using resource tags
- Restrict access to development resources
- Allow read-only access to all EC2 instances
- Explicitly deny tag creation and deletion
- IAM Group-based permission management
- User inherits permissions through IAM Group
- Reusable Terraform variables

---

# 📂 Project Structure

```
terraform-aws-iam-ec2/
│
├── provider.tf
├── variables.tf
├── terraform.tfvars.example
├── main.tf
├── ec2.tf
├── iam.tf
├── outputs.tf
├── README.md
└── .gitignore
```

---

# 📄 File Description

| File | Purpose |
|------|----------|
| provider.tf | AWS Provider configuration |
| variables.tf | Input variables |
| terraform.tfvars.example | Sample variable values |
| ec2.tf | EC2 Instance definitions |
| iam.tf | IAM Policy, Group, User and Attachments |
| outputs.tf | Terraform Outputs |
| README.md | Project Documentation |
| .gitignore | Ignore Terraform state and sensitive files |

---

# ☁️ AWS Resources Created

## EC2 Instances

### Development Server

| Property | Value |
|----------|-------|
| Environment | development |
| Tag | ENV=development |

---

### Production Server

| Property | Value |
|----------|-------|
| Environment | production |
| Tag | ENV=production |

---

## IAM Resources

Terraform creates the following IAM resources:

- IAM Policy
- IAM Group
- IAM User
- Group Policy Attachment
- User Group Membership

---

# 🔐 IAM Policy

The custom IAM policy provides:

## ✅ Allowed Permissions

### Full EC2 Access

Users can perform all EC2 actions **only** on instances tagged:

```
ENV = development
```

Example:

- Start Instance
- Stop Instance
- Reboot Instance
- Terminate Instance
- Modify Instance Attributes

---

### Describe Permissions

Users can view every EC2 instance in the AWS account.

Allowed actions include:

```
ec2:Describe*
```

This allows:

- Describe Instances
- Describe Volumes
- Describe VPCs
- Describe Security Groups
- Describe Subnets
- Describe Tags

---

## ❌ Explicit Deny

The following actions are denied for all resources:

```
ec2:CreateTags
ec2:DeleteTags
```

Because an explicit **Deny** always overrides an **Allow**, users cannot modify tags on any EC2 resource.

---

# 🏷️ Tag-Based Authorization

The IAM policy uses the following condition:

```json
Condition:
{
    "StringEquals":
    {
        "ec2:ResourceTag/ENV": "development"
    }
}
```

This ensures that only EC2 instances tagged with:

```
ENV=development
```

can be managed by the IAM user.

---

# ⚙️ Prerequisites

Before deploying this project, ensure you have:

- AWS Account
- Terraform >= 1.5
- AWS CLI
- Configured AWS Credentials
- EC2 Key Pair
- Amazon Linux AMI ID

---

# 🚀 Deployment

## 1. Clone Repository

```bash
git clone https://github.com/<your-username>/terraform-aws-iam-ec2.git

cd terraform-aws-iam-ec2
```

---

## 2. Initialize Terraform

```bash
terraform init
```

---

## 3. Validate Configuration

```bash
terraform validate
```

---

## 4. Preview Infrastructure

```bash
terraform plan
```

---

## 5. Deploy Infrastructure

```bash
terraform apply
```

Type:

```
yes
```

to confirm.

---

# 📥 Terraform Outputs

After deployment, Terraform outputs:

- Development Instance ID
- Production Instance ID
- IAM User Name
- IAM Group Name
- IAM Policy ARN

Example:

```
development_instance = i-0123456789

production_instance = i-0987654321

iam_user = developer-user
```

---

# 🧪 Testing IAM Permissions

Login using the IAM user or configure AWS CLI with the user's access keys.

### Expected Behavior

| Action | Result |
|---------|--------|
| Describe EC2 Instances | ✅ Allowed |
| Start Development Instance | ✅ Allowed |
| Stop Development Instance | ✅ Allowed |
| Reboot Development Instance | ✅ Allowed |
| Manage Production Instance | ❌ Denied |
| Create Tags | ❌ Denied |
| Delete Tags | ❌ Denied |

---

# 🛠️ Terraform Commands

Initialize

```bash
terraform init
```

Validate

```bash
terraform validate
```

Format

```bash
terraform fmt
```

Plan

```bash
terraform plan
```

Apply

```bash
terraform apply
```

Destroy

```bash
terraform destroy
```

---

# 📌 Variables

| Variable | Description | Default |
|----------|-------------|---------|
| aws_region | AWS Region | us-east-1 |
| instance_type | EC2 Instance Type | t2.micro |
| ami_id | Amazon Linux AMI | User Input |
| key_name | EC2 Key Pair | User Input |
| username | IAM User | developer-user |
| group_name | IAM Group | Developers |

---

# 🔒 Security Notes

- Never commit `terraform.tfvars`.
- Never commit Terraform state files.
- Store secrets securely using AWS Secrets Manager or environment variables.
- Follow the principle of least privilege when creating IAM policies.
- Use remote state (e.g., S3 with DynamoDB locking) for collaborative environments.

---

# 📚 Technologies Used

- Terraform
- Amazon EC2
- AWS IAM
- AWS CLI

---

# 🎯 Learning Outcomes

This project demonstrates:

- Infrastructure as Code (IaC)
- AWS IAM Policy creation
- IAM Groups and Users
- Tag-Based Access Control
- Terraform Variables
- Terraform Outputs
- Terraform Best Practices
- AWS Resource Provisioning
- Access Management using IAM Policies

---

# 👨‍💻 Author

**Huzaifa Sarfraz**

DevOps Engineer

---

# 📄 License

This project is licensed under the MIT License.