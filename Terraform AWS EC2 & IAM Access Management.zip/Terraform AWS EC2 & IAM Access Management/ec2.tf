resource "aws_instance" "development" {

  ami           = var.ami_id
  instance_type = var.instance_type
  key_name      = var.key_name

  tags = {
    Name = "Development-Server"
    ENV  = "development"
  }

}

resource "aws_instance" "production" {

  ami           = var.ami_id
  key_name      = var.key_name
  instance_type = var.instance_type

  tags = {
    Name = "Production-Server"
    Env  = "production"
  }

}
