output "development_instance_id" {

  value = aws_instance.development.id

}

output "production_instance_id" {
  value = aws_instance.production.id

}

output "iam_user" {
  value = aws_iam_user.developer.name

}

output "iam_group" {
  value = aws_iam_group.developers.name

}

output "policy_arn" {
  value = aws_iam_policy.developer_policy.arn

}

output "public_ip_development_instance" {
  value = aws_instance.development.public_ip

}

output "public_ip_production_instance" {
  value = aws_instance.production.public_ip

}

output "account_id" {
  value = data.aws_caller_identity.current.account_id

}

output "iam_console_password" {
  value     = aws_iam_user_login_profile.deveoper.password
  sensitive = true

}
