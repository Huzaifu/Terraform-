data "aws_iam_policy_document" "deveoper-policy" {

  statement {

    sid    = "DevelopmentFullAccess"
    effect = "Allow"
    actions = [
      "ec2:*"
    ]
    resources = [
      "*"
    ]
    condition {
      test     = "StringEquals"
      variable = "ec2:ResourceTag/Env"

      values = [
        "development"
      ]
    }
  }

  statement {

    sid = "DescribeAll"

    effect = "Allow"
    actions = [
      "ec2:Describe*"
    ]
    resources = [
      "*"
    ]

  }

  statement {

    sid    = "DenyCreateTags"
    effect = "Deny"
    actions = [
      "ec2:DeleteTags",
      "ec2:CreateTags"
    ]

    resources = [
      "*"
    ]
  }

}

resource "aws_iam_policy" "developer_policy" {

  name        = "developer-policy"
  description = "Access to development EC2 Instances"

  policy = data.aws_iam_policy_document.deveoper-policy.json

}



# You can alternatively use jsonencode if you have the policy in JSON and directly -
# add in the resource block !! 

resource "aws_iam_group" "developers" {

  name = var.group_name

}

resource "aws_iam_group_policy_attachment" "attach" {

  group      = aws_iam_group.developers.name
  policy_arn = aws_iam_policy.developer_policy.arn

}



resource "aws_iam_user" "developer" {

  name = var.username

}

resource "aws_iam_user_login_profile" "deveoper" {

  user                    = aws_iam_user.developer.name
  password_reset_required = false

}

resource "aws_iam_user_group_membership" "membership" {

  user = aws_iam_user.developer.name
  groups = [
    aws_iam_group.developers.name
  ]

}

data "aws_caller_identity" "current" {

}















