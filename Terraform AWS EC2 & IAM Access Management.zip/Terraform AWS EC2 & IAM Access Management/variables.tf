variable "ami_id" {
  default     = "ami-0b6d9d3d33ba97d99"
  description = "Ubuntu AMI ID"

}

variable "instance_type" {
  default     = "t3.micro"
  description = "instance type for ec2 instance"

}

variable "key_name" {
  default     = "terraform"
  description = "key pair for ec2 instance"


}

variable "username" {
  default = "developer-user"

}

variable "group_name" {
  default = "Developers"

}


