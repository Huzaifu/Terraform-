variable "aws_region" {
  default = "us-east-1"

}

variable "vpc_cidr" {

  default = "10.0.0.0/16"

}

variable "public_subnet_cidr" {
  default = "10.0.0.0/24"

}

variable "availability_zone" {
  default = "us-east-1a"

}


variable "ami_id" {
  default     = "ami-0b6d9d3d33ba97d99"
  description = "Ubuntu AMI ID"

}

variable "instance_type" {
  default     = "t3.micro"
  description = "instance type for ec2 instance"

}

variable "key_name" {
  default     = "terraform"
  description = "key pair for ec2 instance"


}

variable "private_subnet_cidr" {

  default = "10.0.1.0/24"

}
