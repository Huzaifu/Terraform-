resource "aws_network_acl_association" "public_acl_association" {
  subnet_id      = aws_subnet.public_subnet.id
  network_acl_id = aws_network_acl.public_acl.id

}
