resource "aws_security_group" "private_security_group" {
  name   = "Private-Security-Group"
  vpc_id = aws_vpc.terraform.id
  tags = {
    Name = "Private-Security-Group"
  }

}

resource "aws_vpc_security_group_ingress_rule" "allow_ssh_to_public_sg" {
  security_group_id = aws_security_group.private_security_group.id

  referenced_security_group_id = aws_security_group.security_group.id
  ip_protocol                  = "tcp"
  from_port                    = 22
  to_port                      = 22

  description = "Allow ssh to the resources that are part of public SG"

}
