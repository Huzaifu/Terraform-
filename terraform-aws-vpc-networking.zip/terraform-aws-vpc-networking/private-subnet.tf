resource "aws_subnet" "private_subnet" {
  vpc_id = aws_vpc.terraform.id

  cidr_block        = var.private_subnet_cidr
  availability_zone = "us-east-1b"

  tags = {
    Name = "Private-Subnet"
  }


}
