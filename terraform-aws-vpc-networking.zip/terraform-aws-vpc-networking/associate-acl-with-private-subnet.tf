resource "aws_network_acl_association" "private_network_acl_association" {

  subnet_id      = aws_subnet.private_subnet.id
  network_acl_id = aws_network_acl.private_network_acl.id

}
