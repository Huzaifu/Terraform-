resource "aws_subnet" "public_subnet" {

  vpc_id                  = aws_vpc.terraform.id
  cidr_block              = var.public_subnet_cidr
  availability_zone       = var.availability_zone
  map_public_ip_on_launch = true

  tags = {
    Name = "my-terraform-public-subnet"
  }

}
