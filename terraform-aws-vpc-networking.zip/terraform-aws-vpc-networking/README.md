# Terraform AWS VPC Networking Infrastructure

Provision a complete AWS networking environment using **Terraform**. This project creates a production-style VPC with public and private networking components, security controls, and EC2 instances to demonstrate AWS networking fundamentals and Infrastructure as Code (IaC).

---

## 📖 Overview

This project provisions an AWS networking environment that includes:

- Amazon VPC
- Public Subnet
- Private Subnet
- Internet Gateway
- Public Route Table
- Private Route Table
- Public Network ACL
- Private Network ACL
- Security Group
- Public EC2 Instance
- Private EC2 Instance

The infrastructure is completely managed using Terraform.

---

## 🏗️ Architecture

```
                          Internet
                              │
                              │
                   +----------------------+
                   |  Internet Gateway    |
                   +----------+-----------+
                              │
                              │
                 +------------+-------------+
                 | Public Route Table       |
                 | 0.0.0.0/0 → Internet GW  |
                 +------------+-------------+
                              │
                    +---------+---------+
                    |   Public Subnet   |
                    |   10.0.1.0/24     |
                    +---------+---------+
                              │
                  +-----------+-----------+
                  |   Public EC2 Instance |
                  +-----------------------+

      +------------------------------------------------+
      |                     VPC                        |
      |                 10.0.0.0/16                    |
      +------------------------------------------------+
                              │
                    +---------+---------+
                    |  Private Subnet   |
                    |   10.0.2.0/24     |
                    +---------+---------+
                              │
                 +------------+------------+
                 | Private Route Table     |
                 | Local Traffic Only      |
                 +------------+------------+
                              │
                   +----------+----------+
                   | Private EC2 Instance|
                   +---------------------+
```

---

# 🚀 Resources Created

## Networking

- Amazon VPC
- Public Subnet
- Private Subnet
- Internet Gateway
- Public Route Table
- Private Route Table

## Security

- Public Network ACL
- Private Network ACL
- Security Group
- SSH Access Rules

## Compute

- Public EC2 Instance
- Private EC2 Instance

---

# 📂 Project Structure

```
.
├── provider.tf
├── variables.tf
├── main.tf
├── outputs.tf
├── terraform.tfvars
└── README.md
```

---

# ⚙️ Prerequisites

Before deploying, ensure you have:

- AWS Account
- AWS CLI configured
- Terraform installed
- IAM user with sufficient permissions
- EC2 Key Pair

Verify your configuration:

```bash
aws sts get-caller-identity
terraform version
```

---

# 🚀 Deployment

Initialize Terraform

```bash
terraform init
```

Review the execution plan

```bash
terraform plan
```

Deploy the infrastructure

```bash
terraform apply
```

Destroy the infrastructure

```bash
terraform destroy
```

---

# 🔐 Security Configuration

## Security Group

### Inbound

| Protocol | Port | Source |
|----------|------|--------|
| SSH | 22 | 0.0.0.0/0 |

### Outbound

| Protocol | Destination |
|----------|-------------|
| All | 0.0.0.0/0 |

---

## Public Network ACL

### Inbound

Allow All Traffic

### Outbound

Allow All Traffic

---

## Private Network ACL

Configured for the private subnet.

---

# 🧪 Connectivity Testing

Validate the deployment by performing the following tests:

### Public EC2

- Verify that the instance receives a public IP.
- Connect using SSH:
  ```bash
  ssh -i terraform.pem ubuntu@<public-ip>
  ```

### Private EC2

- Verify that the instance does not have a public IP.
- Confirm that direct SSH access from the internet is not possible.
- Access it through the public EC2 instance (bastion host) if configured.

---

# 📤 Outputs

Terraform provides outputs such as:

- VPC ID
- Public Subnet ID
- Private Subnet ID
- Internet Gateway ID
- Security Group ID
- Public EC2 Public IP
- Private EC2 Private IP

---

# 📚 AWS Services Used

- Amazon VPC
- Amazon EC2
- Internet Gateway
- Route Tables
- Security Groups
- Network ACLs
- Terraform

---

# 🎯 Learning Objectives

By completing this project you will learn how to:

- Build AWS infrastructure using Terraform.
- Design a VPC with public and private subnets.
- Configure Internet Gateway and routing.
- Implement Security Groups and Network ACLs.
- Launch EC2 instances in different subnet types.
- Test network connectivity between resources.
- Apply Infrastructure as Code (IaC) best practices.

---

# 🛠️ Future Improvements

- NAT Gateway
- Elastic IP
- Bastion Host
- Auto Scaling Group
- Application Load Balancer
- Multi-AZ Deployment
- VPC Endpoints
- CloudWatch Monitoring
- IAM Roles
- SSM Session Manager
- Terraform Modules

---

# Author

Huzaifa Sarfraz

