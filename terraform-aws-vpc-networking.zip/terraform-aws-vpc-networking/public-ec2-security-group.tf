resource "aws_security_group" "security_group" {
  name        = "public-security-group"
  description = "allow ssh traffic"
  vpc_id      = aws_vpc.terraform.id

  tags = {
    Name = "public-security-group"
  }

}

resource "aws_vpc_security_group_ingress_rule" "allow_ssh" {

  security_group_id = aws_security_group.security_group.id

  cidr_ipv4   = "0.0.0.0/0"
  ip_protocol = "tcp"
  from_port   = 22
  to_port     = 22

  description = "Allow ssh from everywhere"

}

resource "aws_vpc_security_group_egress_rule" "allow_all_outbound" {
  security_group_id = aws_security_group.security_group.id

  cidr_ipv4 = "0.0.0.0/0"

  ip_protocol = "-1"

  description = "Allow all outbound traffic"

}

