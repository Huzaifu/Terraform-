resource "aws_network_acl" "private_network_acl" {
  vpc_id = aws_vpc.terraform.id
  tags = {
    Name = "Private-Network-ACL"
  }

}

resource "aws_network_acl_rule" "allow_ssh" {
  network_acl_id = aws_network_acl.private_network_acl.id
  rule_number    = 100
  protocol       = "-1" # All Protocols
  egress         = false
  rule_action    = "allow"

  cidr_block = "0.0.0.0/0"

  from_port = 22
  to_port   = 22

}

resource "aws_network_acl_rule" "allow_outbound" {
  network_acl_id = aws_network_acl.private_network_acl.id

  rule_number = 100

  egress      = true
  protocol    = "-1"
  rule_action = "allow"

  cidr_block = "0.0.0.0/0"

  to_port   = 0
  from_port = 0

}
