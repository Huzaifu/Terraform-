resource "aws_instance" "public_ec2_instance" {
  subnet_id     = aws_subnet.public_subnet.id
  ami           = var.ami_id
  instance_type = var.instance_type
  key_name      = var.key_name

  vpc_security_group_ids = [
    aws_security_group.security_group.id
  ]


  tags = {
    Name = "Public-subnet-ec2-instance"
  }

}
