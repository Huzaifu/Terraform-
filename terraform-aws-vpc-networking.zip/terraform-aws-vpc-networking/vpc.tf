resource "aws_vpc" "terraform" {

  cidr_block = var.vpc_cidr
  tags = {
    Name = "my-terraform-vpc"
  }

}


