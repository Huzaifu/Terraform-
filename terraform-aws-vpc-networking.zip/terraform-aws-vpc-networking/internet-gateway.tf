resource "aws_internet_gateway" "internet_gateway" {
  vpc_id = aws_vpc.terraform.id
  tags = {
    Name = "my-terraform-vpc-internet-gateway"
  }

}
