resource "aws_instance" "private_ec2" {
  ami           = var.ami_id
  instance_type = var.instance_type
  key_name      = var.key_name
  subnet_id     = aws_subnet.private_subnet.id

  vpc_security_group_ids = [
    aws_security_group.private_security_group.id
  ]

  tags = {
    Name = "Private-subnet-ec2 instance"
  }
}
